#!/usr/bin/env bash
set -euo pipefail
: "${BASE:=/inspire/hdd3/project/intelligent-driving-agent/guoluosong-253108120129/hugsim-reproduction}"
export BASE
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-8}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-8}"
export PYTHONUNBUFFERED=1
bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$BASE/code/HUGSIM"
"$BASE/tools/pixi/bin/pixi" run python "$bundle_dir/check_closed172.py"
exec "$BASE/tools/pixi/bin/pixi" run python "$bundle_dir/closed172_run.py" "$@"
