"""Resident legacy UniAD process. Launched by closed172_run.py only."""
import argparse
import copy
import inspect
import io
import json
import os
import pickle
import sys
import time
import traceback
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np

from closed172_common import atomic_json

JOB = None


def serve(model, namespace):
    import torch
    from uniad_single import TAIL
    from infer_three_pad32 import pad_to_32

    core = getattr(model,"module",model)
    if not np.allclose([core.track_base.score_thresh,
                        core.track_base.filter_score_thresh],[.4,.35]):
        raise RuntimeError("Detection thresholds differ from validated setup")
    if not core.video_test_mode or core.test_track_instances is not None:
        raise RuntimeError("Expected fresh video-mode model")
    adaptations = []
    for name,module in list(model.named_modules()):
        if hasattr(module,"num_cams"):
            if module.num_cams != 6:
                raise RuntimeError("Unexpected camera count: " + name)
            module.num_cams = 3
            adaptations.append(name)
        if hasattr(module,"cams_embeds"):
            old = module.cams_embeds
            if old.shape[0] != 6:
                raise RuntimeError("Unexpected camera embedding")
            module.cams_embeds = torch.nn.Parameter(old.detach()[:3].clone(),requires_grad=False)
    if not adaptations:
        raise RuntimeError("No camera modules adapted")
    core.prev_bev = None
    core.prev_frame_info["prev_bev"] = None
    head = core.planning_head
    if head.training:
        raise RuntimeError("Planning head is in training mode")
    # The external motion-constrained MPC replaces, rather than duplicates,
    # the original pointwise collision postprocessor.
    head.use_col_optim = False
    original_bevs = core.get_bevs
    original_forward = head.forward
    current = {}

    def get_bevs(*args,**kwargs):
        bound = inspect.signature(original_bevs).bind(*args,**kwargs)
        bound.apply_defaults()
        history = original_bevs(*args,**kwargs)
        fresh = dict(bound.arguments)
        fresh.update(prev_bev=None,prev_img=None,prev_img_metas=None)
        metas = copy.deepcopy(fresh["img_metas"])
        for metadata in metas:
            bus = metadata["can_bus"].copy()
            bus[:3] = 0
            bus[-1] = 0
            metadata["can_bus"] = bus
        fresh["img_metas"] = metas
        current["bev"],current["pos"] = original_bevs(**fresh)
        return history

    def planning(*args,**kwargs):
        bound = inspect.signature(original_forward).bind(*args,**kwargs)
        arguments = dict(bound.arguments)
        arguments.update(bev_embed=current["bev"],bev_pos=current["pos"])
        current["planning_calls"] = current.get("planning_calls",0)+1
        return original_forward(**arguments)

    core.get_bevs = get_bevs
    head.forward = planning
    old = ("_cameras = ['CAM_FRONT','CAM_FRONT_RIGHT','CAM_FRONT_LEFT',\n"
           "            'CAM_BACK','CAM_BACK_LEFT','CAM_BACK_RIGHT']")
    marker = "print('Input shape:',tuple(_data['img'].shape),flush=True)"
    if TAIL.count(old) != 1 or TAIL.count(marker) != 1:
        raise RuntimeError("UniAD input template changed")
    tail = TAIL.replace(old,"_cameras = ['CAM_FRONT','CAM_FRONT_RIGHT','CAM_FRONT_LEFT']")
    tail = tail.replace("virtual_rear_views=True","virtual_rear_views=False")
    tail = tail.replace(marker,"_prepare(_data)\n"+marker)
    code = compile(tail,"closed172_three_camera","exec")

    def array(value):
        if hasattr(value,"tensor"):
            value = value.tensor
        if torch.is_tensor(value):
            value = value.detach().cpu().numpy()
        return np.asarray(value)

    atomic_json(JOB/"ready.json",dict(status="ready",uniad_model_loads=1,
                cameras=3,thresholds=[.4,.35],original_collision_postprocessor=False))
    index = 0
    previous_time = None
    try:
        while not (JOB/"stop.json").exists():
            request = JOB/f"request_{index:03d}.json"
            if not request.exists():
                time.sleep(.1)
                continue
            output = JOB/f"step_{index:03d}"
            output.mkdir(exist_ok=True)
            try:
                req = json.loads(request.read_text())
                with Path(req["packet"]).open("rb") as f:
                    _,info = pickle.load(f)
                timestamp = float(info["timestamp"])
                if previous_time is not None and not np.isclose(timestamp-previous_time,.1,atol=1e-6):
                    raise RuntimeError("Non-contiguous simulation timestamp")

                def prepare(data):
                    pad_to_32(data)
                    rotation = np.asarray(info["explicit_l2g_r_mat"],dtype=float)
                    translation = np.asarray(info["explicit_l2g_t"],dtype=float)
                    data["l2g_r_mat"] = data["l2g_r_mat"].new_tensor(rotation.T.copy())
                    data["l2g_t"] = data["l2g_t"].new_tensor(translation)
                    metadata = data["img_metas"][0][0]
                    metadata["scene_token"] = "closed172_"+JOB.name
                    bus = metadata["can_bus"]
                    bus[:3] = [translation[1],-translation[0],0.]
                    yaw = float(np.arctan2(rotation[1,0],rotation[0,0]))%(2*np.pi)
                    bus[-2],bus[-1] = yaw,np.degrees(yaw)

                core.prev_frame_info["prev_bev"] = core.prev_bev
                os.environ["UNIAD_PACKET"] = req["packet"]
                os.environ["UNIAD_SMOKE_OUTPUT"] = str(output)
                scope = dict(namespace,model=model,_prepare=prepare)
                current["planning_calls"] = 0
                stream = io.StringIO()
                try:
                    with redirect_stdout(stream),torch.no_grad():
                        exec(code,scope)
                finally:
                    (output/"inference.log").write_text(stream.getvalue())
                if current["planning_calls"] != 1:
                    raise RuntimeError("Unexpected number of planning calls")
                result = scope["_results"][0]
                occupancy = result.get("occ",{}).get("seg_out")
                if occupancy is None:
                    raise RuntimeError("Missing predicted occupancy")
                plan = array(result["planning"]["result_planning"]["sdc_traj"]).reshape(6,2)
                if not np.isfinite(plan).all():
                    raise RuntimeError("Nonfinite neural plan")
                saved = dict(trajectory=plan,occupancy=array(occupancy))
                for name,key in [("boxes","boxes_3d"),("scores","scores_3d"),
                                 ("labels","labels_3d"),("candidate_boxes","boxes_3d_det"),
                                 ("candidate_scores","scores_3d_det"),
                                 ("candidate_labels","labels_3d_det")]:
                    if result.get(key) is not None:
                        saved[name] = array(result[key])
                target = output/"perception.npz"
                np.savez_compressed(target,**saved)
                atomic_json(JOB/f"done_{index:03d}.json",dict(status="ok",index=index,
                            timestamp=timestamp,perception=str(target),
                            inference_seconds=float(scope["_elapsed"])))
                previous_time = timestamp
                del result,saved,scope
                current.clear()
                index += 1
            except BaseException as exc:
                traceback.print_exc()
                atomic_json(JOB/f"done_{index:03d}.json",dict(status="error",error=repr(exc)))
                raise
    finally:
        core.get_bevs = original_bevs
        head.forward = original_forward


def main():
    global JOB
    parser = argparse.ArgumentParser()
    parser.add_argument("--job",required=True)
    args = parser.parse_args()
    JOB = Path(args.job).resolve()
    base = Path(os.environ["BASE"])
    sys.path.insert(0,str(base/"waymo23-native-import"))
    import five_uniad
    os.environ["FIVE_JOB"] = str(JOB/"step_000")
    five_uniad.infer_five = serve
    try:
        five_uniad.infer()
    except BaseException as exc:
        atomic_json(JOB/"worker_error.json",dict(status="error",error=repr(exc)))
        raise


if __name__ == "__main__":
    main()
