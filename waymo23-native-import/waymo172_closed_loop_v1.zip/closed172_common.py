"""Pure CPU geometry, IPC and diagnostic MPC; no simulator/model imports."""
import json
import os
import time
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.spatial import cKDTree

B = np.array([[1.,0,0,0],[0,0,1,0],[0,-1,0,0],[0,0,0,1]])


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False))
    os.replace(tmp, path)


def atomic_pickle(path, value):
    import pickle
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        pickle.dump(value, f, protocol=4)
    os.replace(tmp, path)


def wait_json(path, process, timeout=300.):
    begin = time.monotonic()
    path = Path(path)
    while not path.exists():
        if process.poll() is not None:
            raise RuntimeError("UniAD worker exited; inspect uniad_worker.log")
        if time.monotonic() - begin > timeout:
            raise TimeoutError("Worker response timeout: " + str(path))
        time.sleep(0.1)
    result = json.loads(path.read_text())
    if result.get("status") == "error":
        raise RuntimeError(result.get("error", "worker error"))
    return result


def native_delta(x, forward, yaw):
    c, s = np.cos(yaw), np.sin(yaw)
    result = np.eye(4)
    result[:3,:3] = [[c,0,s],[0,1,0],[-s,0,c]]
    result[:3,3] = [x,0,forward]
    return result


def initial_native_pose(info):
    pose = np.eye(4)
    pose[:3,:3] = np.asarray(info["explicit_l2g_r_mat"])
    pose[:3,3] = np.asarray(info["explicit_l2g_t"])
    c = np.asarray(info["model_lidar_frame"]["virtual_to_ego"])
    return np.linalg.inv(B) @ pose @ np.linalg.inv(c) @ B


def virtual_global_pose(native_pose, c):
    return B @ native_pose @ np.linalg.inv(B) @ c


def integrate_state(state, action, dt=.1, wheelbase=2.7):
    """Native planar (right,forward,yaw-right,speed,steer) update order."""
    x, y, yaw, speed, steer = map(float, state)
    acc, rate = map(float, action)
    speed += acc * dt
    steer += rate * dt
    x += speed * np.sin(yaw) * dt
    y += speed * np.cos(yaw) * dt
    yaw += speed * np.tan(steer) / wheelbase * dt
    return np.array([x,y,yaw,speed,steer])


def rollout(controls, speed, steer, offset, dt=.1, wheelbase=2.7):
    # Start at current simulator origin, expressed in current virtual LiDAR.
    start = -np.asarray(offset, dtype=float)
    state = np.array([*start,0.,speed,steer], dtype=float)
    states = [state.copy()]
    lidar = [np.zeros(2)]
    for action in np.asarray(controls).reshape(6,2):
        for _ in range(5):
            state = integrate_state(state, action, dt, wheelbase)
            states.append(state.copy())
            yaw = state[2]
            ox = np.cos(yaw)*offset[0] + np.sin(yaw)*offset[1]
            oy = -np.sin(yaw)*offset[0] + np.cos(yaw)*offset[1]
            lidar.append(state[:2] + [ox,oy])
    return np.asarray(states), np.asarray(lidar)


def optimize(reference, occupancy, info, warm=None, maxiter=220):
    reference = np.asarray(reference, dtype=float).reshape(6,2)
    masks = np.asarray(occupancy)
    if masks.ndim == 5:
        masks = masks.squeeze(2)
    if masks.shape != (1,5,200,200) or not np.isfinite(masks).all():
        raise ValueError("Unexpected occupancy: " + str(masks.shape))
    # Predicted labels only. Ground truth is never used here.
    rc = np.argwhere(np.any(masks[0] != 0, axis=0))
    if not len(rc):
        raise ValueError("Empty occupancy: stop diagnostic instead of assuming safe")
    occupied = (rc[:,[1,0]].astype(float)-100.)*.5+.25
    tree = cKDTree(occupied)
    c = np.asarray(info["model_lidar_frame"]["virtual_to_ego"],dtype=float)
    if not np.allclose(c[:3,:3], np.eye(3)):
        raise ValueError("Only axis-aligned virtual mount supported")
    offset = c[:2,3]
    speed, steer = float(info["ego_velo"]), float(info["ego_steer"])
    if speed < -1e-6 or not np.isfinite([speed,steer]).all():
        raise ValueError("Invalid initial motion state")
    radius = float(np.hypot(.8,1.5)+.2+np.sqrt(2)*.25)
    rate_limit = np.deg2rad(15.)
    bounds = [b for _ in range(6) for b in [(-2.,2.),(-rate_limit,rate_limit)]]

    def clear(states):
        centers = states[:,:2]
        distances, _ = tree.query(centers)
        half = np.linalg.norm(np.diff(centers,axis=0),axis=1)/2
        allowance = np.zeros(len(centers))
        allowance[:-1] = np.maximum(allowance[:-1],half)
        allowance[1:] = np.maximum(allowance[1:],half)
        return distances-radius-allowance

    def constraints(flat):
        states,_ = rollout(flat,speed,steer,offset)
        return np.r_[clear(states), states[:,3], np.deg2rad(80.)-np.abs(states[:,4])]

    def objective(flat):
        controls = np.asarray(flat).reshape(6,2)
        _,lidar = rollout(controls,speed,steer,offset)
        changes = np.diff(controls,axis=0)
        return float(np.sum((lidar[5::5]-reference)**2)
                     +.1*np.sum(controls[:,0]**2)+2*np.sum(controls[:,1]**2)
                     +.5*np.sum(changes[:,0]**2)+5*np.sum(changes[:,1]**2))

    seeds = []
    if warm is not None:
        previous = np.asarray(warm,dtype=float).reshape(6,2)
        shifted = np.stack([np.interp(np.arange(6)*.5+.1,
                            np.arange(6)*.5, previous[:,j]) for j in range(2)],axis=1)
        seeds.append(("warm",shifted))
    seeds.append(("coast",np.zeros((6,2))))
    brake = np.zeros((6,2)); brake[:,0] = -1.9
    seeds.append(("brake",brake))
    left = np.array([[-1.5,-.24],[-1.5,-.20],[-1.,.05],[-.5,.20],[0,.15],[0,0.]])
    seeds.append(("left_brake",left))
    right = left.copy(); right[:,1] *= -1
    seeds.append(("right_brake",right))
    trials = []
    selected = None
    for name, seed in seeds:
        sol = minimize(objective,seed.ravel(),method="SLSQP",bounds=bounds,
                       constraints=[{"type":"ineq","fun":constraints}],
                       options={"maxiter":maxiter,"ftol":1e-6,"disp":False})
        states,lidar = rollout(sol.x,speed,steer,offset)
        residual = float(constraints(sol.x).min())
        clearance = float(clear(states).min())
        controls = sol.x.reshape(6,2)
        controls_valid = bool(np.all(np.abs(controls[:,0]) <= 2.+1e-8)
                              and np.all(np.abs(controls[:,1]) <= rate_limit+1e-8))
        feasible = bool(sol.success and np.isfinite(states).all()
                        and residual >= -1e-5 and controls_valid)
        row = dict(seed=name,solver_success=bool(sol.success),message=str(sol.message),
                   feasible=feasible,minimum_constraint=residual,
                   clearance_lower_bound_m=clearance,objective=float(objective(sol.x)),
                   controls=controls.tolist(),states=states.tolist(),lidar=lidar.tolist())
        trials.append(row)
        if feasible:
            selected = row
            # Receding-horizon feasibility, not a global optimality claim.
            break
    return dict(selected=selected,trials=trials,occupied_union_cells=int(len(rc)),
                ground_truth_used_by_optimizer=False,
                policy="first feasible multistart candidate; warm start first",
                steering_physical_limit_validated=False)


def asset_reference_vertices(asset):
    width,length,height = map(float,asset["asset_wlh"])
    bottom = float(asset["local_bottom_y"])
    local = np.array([[x,bottom,z,1.] for x,z in
                      [(-length/2,-width/2),(length/2,-width/2),
                       (length/2,width/2),(-length/2,width/2)]])
    placement = next(p for p in asset["placements"] if p["case"] == "heading_A")
    return (np.asarray(placement["asset_to_native"]) @ local.T).T[:,:3]


def body_vertices(native_pose):
    local = np.array([[x,0,z,1.] for x,z in
                      [(-.8,-1.5),(.8,-1.5),(.8,1.5),(-.8,1.5)]])
    return (native_pose @ local.T).T[:,:3]


def polygon_check(a,b):
    """Convex polygon SAT + exact segment distances; no OpenCV dependency."""
    a,b = np.asarray(a,dtype=float),np.asarray(b,dtype=float)
    separated = False
    for poly in (a,b):
        for edge in np.roll(poly,-1,axis=0)-poly:
            axis = np.array([-edge[1],edge[0]])
            if np.linalg.norm(axis) < 1e-12:
                continue
            pa,pb = a @ axis,b @ axis
            if pa.max() < pb.min()-1e-9 or pb.max() < pa.min()-1e-9:
                separated = True
    if not separated:
        return dict(overlap=True,gap_m=0.)
    gaps = []
    for points,segments in ((a,b),(b,a)):
        for p in points:
            for q,r in zip(segments,np.roll(segments,-1,axis=0)):
                delta = r-q
                t = np.clip(np.dot(p-q,delta)/max(np.dot(delta,delta),1e-20),0,1)
                gaps.append(np.linalg.norm(p-(q+t*delta)))
    return dict(overlap=False,gap_m=float(min(gaps)))


def reference_check(native_pose, asset):
    # World horizontal plane is native X/Z. Asset truth only evaluates the run.
    body = body_vertices(native_pose)
    target = asset_reference_vertices(asset)
    result = polygon_check(body[:,[0,2]],target[:,[0,2]])
    result.update(body_world_xz=body[:,[0,2]].tolist(),
                  target_world_xz=target[:,[0,2]].tolist())
    return result
